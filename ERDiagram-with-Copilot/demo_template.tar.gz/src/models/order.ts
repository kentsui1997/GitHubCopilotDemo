export interface Order {
  orderId: number;
  orderDate: Date;
  headquartersId: number;
}

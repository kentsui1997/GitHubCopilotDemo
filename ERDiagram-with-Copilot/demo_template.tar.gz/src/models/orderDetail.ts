export interface OrderDetail {
  orderDetailId: number;
  productId: number;
  orderId: number;
  productQuantity: number;
}
